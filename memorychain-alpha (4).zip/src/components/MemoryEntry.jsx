export default function MemoryEntry({ entry }) {
  return <div>{entry.content}</div>;
}